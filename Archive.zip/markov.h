#ifndef __MARKOV_H__
#define __MARKOV_H__
#include "adjacency.h"

int isMarkovGraph(t_adjacency_list * adjList);
#endif
#ifndef BONUS_H
#define BONUS_H
#include "matrix.h"

int getPeriod(t_matrix * sub_matrix);
int gcd(int *vals, int nbvals);
#endif 
